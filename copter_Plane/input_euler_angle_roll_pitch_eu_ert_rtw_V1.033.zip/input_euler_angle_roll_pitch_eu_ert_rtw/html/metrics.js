function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtInf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	size: 4};
	 this.metricsArray.var["rtMinusInf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	size: 4};
	 this.metricsArray.fcn["acos"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["asin"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["atan"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["atan2"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["cos"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmax"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmin"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmod"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:AP_MotorsMulticopter_output"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 65,
	stackTotal: 98};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:ang_vel_limit"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 40,
	stackTotal: 72};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:attitude_controller_run_quat"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 380,
	stackTotal: 452};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:auto_mode"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 52,
	stackTotal: 660};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:auto_mode_sl"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 48,
	stackTotal: 656};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:calc_nav_pitch"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:calc_nav_roll"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:copter_run"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 24,
	stackTotal: 608};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:from_axis_angle"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:from_euler"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 64,
	stackTotal: 64};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:from_rotation_matrix"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:get_bearing_to"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 49};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:get_distance_NE"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:get_vector_xy_from_origin_NE"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:get_weathervane_yaw_rate_cds"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:input_euler_angle_roll_pitch__o"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 132,
	stackTotal: 584};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:norm"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:norm_j"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:normalizeq"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:output_to_motors_plane"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:plane_run"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 88};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:prevent_indecision"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 50};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:quatmultiply"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rate_controller_run"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rotation_matrix"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 72,
	stackTotal: 72};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtGetInf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtGetInfF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtGetMinusInf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtGetMinusInfF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtGetNaN"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtGetNaNF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtIsInf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtIsInfF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtIsNaN"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 13,
	stackTotal: 17};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rtIsNaNF"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:rt_InitInfAndNaN"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 24};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:run_xy_controller"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 53,
	stackTotal: 86};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:set_alt_target_from_climb_ra_g4"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:set_alt_target_from_climb_rat_g"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:set_alt_target_from_climb_rate_"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:set_throttle_out"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:setup_motors"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:sqrt_controller"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:stabilize"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 60,
	stackTotal: 60};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:update_50hz"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:update_loiter"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 72,
	stackTotal: 122};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:update_pitch_throttle"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 80,
	stackTotal: 80};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:update_vel_controller_xy"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 8,
	stackTotal: 94};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:update_waypoint"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 80,
	stackTotal: 130};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:update_z_controller"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 48};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu.c:wrap_PI"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 17,
	stackTotal: 34};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu_initialize"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 4,
	stackTotal: 28};
	 this.metricsArray.fcn["input_euler_angle_roll_pitch_eu_step"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 96,
	stackTotal: 756};
	 this.metricsArray.fcn["memcpy"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_atan2d_snf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 33};
	 this.metricsArray.fcn["rt_remd_snf"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 16,
	stackTotal: 33};
	 this.metricsArray.fcn["sin"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["tan"] = {file: "D:\\Program Files\\Polyspace\\R2020a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["trunc"] = {file: "E:\\matlab_code\\Copter_Plane_Backup\\Copter_Git\\V10\\input_euler_angle_roll_pitch_eu_ert_rtw\\input_euler_angle_roll_pitch_eu.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="input_euler_angle_roll_pitch_eu_metrics.html">Global Memory: 36(bytes) Maximum Stack: 380(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
